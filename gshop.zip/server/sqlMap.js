var sqlMap = {
  getValue: 'SELECT * FROM user WHERE username = ?',
  setValue: 'UPDATE user SET password = ? WHERE username = ?',
	insertValue: 'insert into user (username,password) value(?,?)'
}

module.exports = sqlMap;