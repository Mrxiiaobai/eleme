export const RECEIVE_DETAIl = 'receive_detail'
export const RECEIVE_SHOPS = 'receive_shops'