<template>
  <div class="cart">
		<headTop title='订单列表'>
		</headTop>
		<div class="bannerDownload">
			<img src="http://ms0.meituan.net/touch/img/download_banner.png" alt="">
			<span></span>
			<span></span>
			<div><img src="" alt=""></div>
		</div>
		
		<div v-bind:class="{ts:arr[0].Data === undefined ? true:false}" v-if="arr[0].Data === undefined ? true:false">当前没有订单</div>
		<div class="foodFooter" v-bind:style="{display:arr[0].Data === undefined ? 'none':'block'}">
			<div class="guess-like">订单</div>
			<div class="footerShop">
				<div class="food" v-for="(value,key) in arr">
		    		<div class="foodRight">
		    			<p>
		    				<span>{{value.businessName}}</span>
		    			</p>
		    			<p>
							<span class="col">￥{{value.totalMoney}}/人</span>
							<span class="col">{{value.Data}}</span>
		    			</p>
		    		</div>
				</div>
			</div>
		</div>
  </div>
</template>

<script>
import headTop from '../headTop/headTop.vue'
import axios from "axios"

export default {
	name: 'cart',
	data(){
		return {
			shop:{}
		}
	},
	mounted(){
		// if(this.$route.query.businessName === undefined){
		// 	this.mui.createMask(this.callback);//callback为用户点击蒙版时自动执行的回调；
		// }
		console.log(this.$route.query.businessName);
	},
	components:{
		headTop  
	},
	methods:{

	},
	computed:{
		arr(){
			var that = this;
			let arr = [];
				console.log(that.shop);
				that.shop["businessName"] = this.$route.query.businessName;
				that.shop["totalMoney"] = this.$route.query.totalMoney;
				that.shop["Data"] = this.$route.query.Data;
				arr.push(this.shop);
				console.log(that.shop);
				console.log(arr);
				return arr;
		}
	}
}

</script>
<style scoped>
	.bannerDownload{
		width: 100%;
		height: 2.1rem;
		border-bottom: 1px solid #c6c0b3;
	}
	.bannerDownload img{
		width: 100%;
		height: 100%;
	}
	.ts {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0.9rem;
    left: 0;
    z-index: 998;
    background-color: rgba(0,0,0,.3);
	text-align: center;
	padding-top: 70%;
	font-size: 0.4rem;
	color: #fff;
}
</style>
