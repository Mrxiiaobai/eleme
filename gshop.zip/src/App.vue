<template>
  <div id="app">
		<keep-alive :include="['index']">
			<router-view></router-view>	
		</keep-alive>
    <!-- <keep-alive v-if="!$route.meta.keepAlive">
    	<router-view></router-view>	
    </keep-alive> -->
		<keep-alive include="common">
			<common v-show="$route.meta.showFooter"></common>
		</keep-alive>
		
    
  </div>
</template>

<script>
import common from "./components/footer/common.vue"

export default {
  name: 'app',
	mounted(){
		this.$store.dispatch('getShops');
		this.$store.dispatch('getDetails');
	},
  components:{
    common
  },
	methods:{
		
	},
	beforeRouteEnter(to, from, next) {
      next(vm => {
          // 通过 `vm` 访问组件实例
            if (from.fullPath == '/' && to.fullPath == '/order') {//一定是从A进到B页面才刷新
                // vm.updata();//updataB是本来写在mounted里面的各种
            }
      })
	}
	// beforeRouteLeave(to,from,next){
	// 	  if(to.name == 'deal'){
	// 		  console.log(2);
	// 		  if(!from.meta.keepAlive){
	// 				from.meta.keepAlive = true;
	// 			}
	// 			next();
	// 	  }else{
	// 		  from.meta.keepAlive = false;
	// 		  to.meta.keepAlive = false;
	// 		  this.$destroy();
	// 		  next();
	// 	  }
	// }
}

</script>

<style>
*{ 
	touch-action: pan-y;
	list-style: none;
}

.el-message-box{
	width: 90%;
	margin-top: -100%;
}

</style>
